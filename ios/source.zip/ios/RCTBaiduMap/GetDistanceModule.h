//  GetDistanceModule.h
//  RCTBaiduMap
//
//  Created by sybil052 on 2017/5/5.
//  https://www.jianshu.com/p/bd8335c40aa3

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>
#import <UIKit/UIKit.h>
#import <BaiduMapAPI_Utils/BMKGeometry.h>
#import <React/RCTEventDispatcher.h>

@interface GetDistanceModule : NSObject<RCTBridgeModule>

@end
