//
//  BaiduMapAppModule.h
//  RCTBaiduMap
//
//  Created by lovebing on 2019/10/31.
//  Copyright © 2019 lovebing.org. All rights reserved.
//

#ifndef BaiduMapAppModule_h
#define BaiduMapAppModule_h

#import <React/RCTBridgeModule.h>
#import <BaiduMapAPI_Utils/BMKUtilsComponent.h>
#import "OverlayUtils.h"

@interface BaiduMapAppModule : NSObject<RCTBridgeModule>

@end

#endif /* BaiduMapAppModule_h */
