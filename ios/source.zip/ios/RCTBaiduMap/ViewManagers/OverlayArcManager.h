//
//  OverlayArcManager.h
//  RCTBaiduMap
//
//  Created by lovebing on 2020/5/16.
//  Copyright © 2020 lovebing.net. All rights reserved.
//

#ifndef OverlayArcManager_h
#define OverlayArcManager_h

#import "OverlayArc.h"
#import <React/RCTViewManager.h>

@interface OverlayArcManager : RCTViewManager

@end

#endif /* OverlayArcManager_h */
