//
//  OverlayMarkerManager.h
//  Pods
//
//  Created by lovebing on 2019/10/7.
//  Copyright © 2019年 lovebing.org. All rights reserved.
//

#ifndef OverlayMarkerManager_h
#define OverlayMarkerManager_h

#import "OverlayMarker.h"
#import <React/RCTViewManager.h>

@interface OverlayMarkerManager : RCTViewManager

@end


#endif /* OverlayMarkerManager_h */
