//
//  OverlayPolylineManager.h
//  Pods
//
//  Created by lovebing on 2019/10/7.
//  Copyright © 2019年 lovebing.org. All rights reserved.
//

#ifndef OverlayPolylineManager_h
#define OverlayPolylineManager_h

#import "OverlayPolyline.h"
#import <React/RCTViewManager.h>

@interface OverlayPolylineManager : RCTViewManager

@end

#endif /* OverlayPolylineManager_h */
