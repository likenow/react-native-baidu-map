//
//  OverlayCircleManager.h
//  RCTBaiduMap
//
//  Created by lovebing on 2020/5/16.
//  Copyright © 2020 lovebing.net. All rights reserved.
//

#ifndef OverlayCircleManager_h
#define OverlayCircleManager_h

#import "OverlayCircle.h"
#import <React/RCTViewManager.h>

@interface OverlayCircleManager : RCTViewManager

@end

#endif /* OverlayCircleManager_h */
