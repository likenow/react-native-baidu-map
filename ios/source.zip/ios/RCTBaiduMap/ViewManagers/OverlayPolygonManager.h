//
//  OverlayPolygonManager.h
//  RCTBaiduMap
//
//  Created by lovebing on 2020/5/16.
//  Copyright © 2020 lovebing.org. All rights reserved.
//

#ifndef OverlayPolygonManager_h
#define OverlayPolygonManager_h

#import "OverlayPolygon.h"
#import <React/RCTViewManager.h>

@interface OverlayPolygonManager : RCTViewManager

@end

#endif /* OverlayPolygonManager_h */
