//
//  InfoWindowManager.h
//  RCTBaiduMap
//
//  Created by lovebing on 2020/5/16.
//  Copyright © 2020 lovebing.net. All rights reserved.
//

#ifndef InfoWindowManager_h
#define InfoWindowManager_h

#import "InfoWindow.h"
#import <React/RCTViewManager.h>

@interface InfoWindowManager : RCTViewManager

@end

#endif /* InfoWindowManager_h */
