//
//  OverlayHeatMapManager.h
//  RCTBaiduMap
//
//  Created by lovebing on 2020/5/23.
//  Copyright © 2020 lovebing.net. All rights reserved.
//

#ifndef OverlayHeatMapManager_h
#define OverlayHeatMapManager_h

#import "OverlayHeatMap.h"
#import <React/RCTViewManager.h>

@interface OverlayHeatMapManager : RCTViewManager

@end

#endif /* OverlayHeatMapManager_h */
