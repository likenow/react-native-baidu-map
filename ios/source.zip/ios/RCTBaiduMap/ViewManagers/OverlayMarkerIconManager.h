//
//  OverlayMarkerIconManager.h
//  RCTBaiduMap
//
//  Created by lovebing on 2020/6/7.
//  Copyright © 2020 lovebing.org. All rights reserved.
//

#ifndef OverlayMarkerIconManager_h
#define OverlayMarkerIconManager_h

#import "OverlayMarkerIcon.h"
#import <React/RCTViewManager.h>

@interface OverlayMarkerIconManager : RCTViewManager

@end

#endif /* OverlayMarkerIconManager_h */
